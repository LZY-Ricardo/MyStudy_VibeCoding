import './index.css'

export default function Demo() {
  return (
    <div className='box'>
      Demo
    </div>
  )
}
