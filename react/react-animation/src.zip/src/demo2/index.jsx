import React from 'react'
import './index.css'

export default function Demo2() {
  return (
    <div className='box'>Demo2</div>
  )
}
