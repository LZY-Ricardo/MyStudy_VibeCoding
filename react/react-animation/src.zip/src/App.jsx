// import Demo from './demo1/index.jsx' // css 中的过渡动画

// import Demo2 from './demo2/index.jsx' // css 中的复杂动画

// import Demo3 from './demo3/index.jsx' // animate.css 动画库

import Demo4 from './demo4/index.jsx' // react动画库 react-spring

export default function App() {
  return (
    <div>
      {/* <Demo /> */}
      {/* <Demo2 /> */}
      {/* <Demo3 /> */}
      <Demo4 />
    </div>
  )
}
