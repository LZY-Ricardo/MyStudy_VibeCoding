import React from 'react'
import 'animate.css'

export default function Demo3() {
  return (
    <div>
        <h1 className='animate__animated animate__backInDown'>animate.css 动画库</h1>
    </div>
  )
}
